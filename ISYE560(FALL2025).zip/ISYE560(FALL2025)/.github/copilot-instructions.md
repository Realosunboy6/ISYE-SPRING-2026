# ISYE 560 Facility Planning Project - AI Coding Agent Instructions

## Project Overview
This is an academic project for ISYE 560 (Industrial Engineering) focusing on **facility layout optimization algorithms**. The project implements classical algorithmic approaches for optimizing machine-part assignments and facility layouts using Julia.

## Key Components & Architecture

### 1. **Direct Clustering Algorithm (DCA)** - PROJECT_ISYE560.ipynb
- **Purpose**: Assigns parts to machines by grouping machine-part relationships to minimize workflow complexity
- **Key Concept**: Lexicographic sorting (1s move LEFT, 1s move UP) to create block-diagonal matrix structure
- **Workflow**:
  - Step 2: Initial matrix ordering (rows descending by 1-count, columns ascending)
  - Step 3: Lexicographic sorting to cluster related machines/parts
  - Displays machine-part incidence matrix with row/column sums
- **Critical Function**: `display_matrix()` formats the incidence matrix with sums for analysis

### 2. **Pairwise Exchange Algorithm** - Pairwise Exchange Algorithm.ipynb
- **Purpose**: Optimizes facility layout by minimizing total flow distance through iterative swaps
- **Key Concept**: Evaluates all possible pairwise exchanges to find best layout improvement
- **Workflow**:
  1. Define flow matrix `f` (flow between departments)
  2. Define department positions as (x,y) coordinates in layout
  3. Compute Manhattan distance matrix from current layout
  4. Calculate objective Z = Σ(flow_ij × distance_ij)
  5. Iterate: try all pairwise swaps, select swap with highest ΔZ improvement
  6. Stop when no improvement found (local optimum)
- **Critical Functions**:
  - `distance_matrix()`: Computes Manhattan distances for current layout
  - `compute_Z()`: Objective value using flow × distance
  - `iterate_once()`: Evaluates all N(N-1)/2 possible pairwise exchanges
  - `pairwise_exchange_full()`: Main loop until convergence

## Julia-Specific Patterns

### Code Structure
- **Matrix Operations**: Direct indexing (1-based), comprehensions for transformations
- **Formatting**: Use `@printf()` for aligned output, `join()` for string concatenation
- **DataFrames**: Import for tabular output in optimization iterations

### Data Organization Conventions
- **Incidence Matrix**: 1 = relationship exists, - = no relationship
- **Coordinate System**: (x,y) tuples with offset layouts (e.g., dept 4 under dept 2)
- **Flow Matrix**: Square n×n matrix where f[i,j] = flow from dept i to dept j

## Critical Implementation Details

### Pairwise Exchange Algorithm
- **Convergence**: Stop when best_swap improvement ≤ 0
- **Multiple Optima**: When multiple layouts yield same minimum Z, return all (not just first)
- **Output Format**: Print iteration details with layout, Z_new, and ΔZ for each candidate
- **No Global Search**: Algorithm terminates at local minimum—initial layout matters

### DCA Matrix Display
- **Part/Machine Labels**: Preserve original labels from input (not sequential indices)
- **Row/Column Ordering**: Sort separately (rows desc by count, columns asc by count)
- **Tie-Breaking**: Use descending numerical/alphabetical order when 1-counts equal

## Development Workflows

### Running Notebooks
- Julia kernel required in VS Code (Jupyter extension)
- Execute cells in order (DCA and Pairwise are independent notebooks)
- Notebooks have pre-computed outputs; re-run cells to regenerate with modified parameters

### Testing Patterns
- **Test Data**: Hardcoded matrices in notebooks (ICA 10 example in Pairwise notebook)
- **Validation**: Compare computed Z values against manual calculations
- **Visualization**: Matrix display and iteration tables serve as primary validation

## Common Pitfalls & Project-Specific Wisdom

1. **Layout Representation Matters**: Department positions use 2D grid coordinates, not sequential; offset layouts require careful coordinate specification
2. **Lexicographic vs Numeric Sorting**: DCA uses lexicographic sorting (1s move left/up), not simple numerical sorting
3. **Tie-Handling in Optimization**: When multiple swaps yield same improvement, preserve all candidates (don't filter to one)
4. **Manhattan vs Euclidean Distance**: This project uses Manhattan distance (|x₁-x₂| + |y₁-y₂|), not Euclidean
5. **Flow Matrix Asymmetry**: Flow matrices are generally asymmetric (flow i→j ≠ flow j→i)

## File Organization
- `.git/` - Version control (preserve workflow history)
- `*.pdf` - Course materials (HW sheets, ICA assignments, project specs)
- Two main `.ipynb` notebooks - independent implementations
- No external data files; all test cases hardcoded in notebooks

## Key Questions to Ask When Adding Features
- Does this modify the optimization criterion (currently: minimize total weighted distance)?
- Does this change matrix representation or ordering rules?
- Should this work in both DCA and Pairwise notebooks or just one?
- Does this require new Julia dependencies beyond Printf and DataFrames?
